﻿using System;
using System.Collections.Generic;
//using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using WFComercialWebApp.Models;
using Bitacora;
using NLog;

namespace WFComercialWebApp.Controllers
{
    public class InstanciaController : Controller
    {
        private RiesgosComercialesEntities db = new RiesgosComercialesEntities();

        // GET: /Instancia/
        public ActionResult Index()
        {
            return View(db.Instancia.ToList());
        }

        // GET: /Instancia/Details/5
        public ActionResult Details(int? id)
        {
            try
            {
                if (id == null)
                {
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                }
                Instancia instancia = db.Instancia.Find(id);
                if (instancia == null)
                {
                    return HttpNotFound();
                }
                return View(instancia);
            }
            catch (Exception ex)
            {
                GestorEventos.LogError(LogManager.GetCurrentClassLogger(), "APLICATIVO WFCOMERCIAL - Details GET ", ex);
                return null;
                throw;
            }
        }

        // GET: /Instancia/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: /Instancia/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "InstanciaID,Nombre,FechaRegistro")] Instancia instancia)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    GestorEventos.LogInformacion(LogManager.GetCurrentClassLogger(), "APLICATIVO WFCOMERCIAL - Create " + instancia.InstanciaID.ToString() + " USUARIO:" + User.Identity.Name.ToUpper().Substring(7));
                    db.Instancia.Add(instancia);
                    db.SaveChanges();
                    return RedirectToAction("Index");
                }

                return View(instancia);
            }
            catch (Exception ex)
            {
                GestorEventos.LogError(LogManager.GetCurrentClassLogger(), "APLICATIVO WFCOMERCIAL - Create POST ", ex);
                return null;
                throw;
            }
        }

        // GET: /Instancia/Edit/5
        public ActionResult Edit(int? id)
        {
            try
            {
                if (id == null)
                {
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                }
                Instancia instancia = db.Instancia.Find(id);
                if (instancia == null)
                {
                    return HttpNotFound();
                }
                return View(instancia);
            }
            catch (Exception ex)
            {
                GestorEventos.LogError(LogManager.GetCurrentClassLogger(), "APLICATIVO WFCOMERCIAL - Edit GET ", ex);
                return null;
                throw;
            }
        }

        // POST: /Instancia/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "InstanciaID,Nombre,FechaRegistro")] Instancia instancia)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    GestorEventos.LogInformacion(LogManager.GetCurrentClassLogger(), "APLICATIVO WFCOMERCIAL - Edit " + instancia.InstanciaID.ToString() + " USUARIO:" + User.Identity.Name.ToUpper().Substring(7));
                    db.Entry(instancia).State = EntityState.Modified;
                    db.SaveChanges();
                    return RedirectToAction("Index");
                }
                return View(instancia);
            }
            catch (Exception ex)
            {
                GestorEventos.LogError(LogManager.GetCurrentClassLogger(), "APLICATIVO WFCOMERCIAL - Edit POST ", ex);
                return null;
                throw;
            }
        }

        // GET: /Instancia/Delete/5
        public ActionResult Delete(int? id)
        {
            try
            {
                if (id == null)
                {
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                }
                Instancia instancia = db.Instancia.Find(id);
                if (instancia == null)
                {
                    return HttpNotFound();
                }
                return View(instancia);
            }
            catch (Exception ex)
            {
                GestorEventos.LogError(LogManager.GetCurrentClassLogger(), "APLICATIVO WFCOMERCIAL - Delete GET ", ex);
                return null;
                throw;
            }
        }

        // POST: /Instancia/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            try
            {
                GestorEventos.LogInformacion(LogManager.GetCurrentClassLogger(), "APLICATIVO WFCOMERCIAL - DeleteConfirmed " + id.ToString() + " USUARIO:" + User.Identity.Name.ToUpper().Substring(7));
                Instancia instancia = db.Instancia.Find(id);
                db.Instancia.Remove(instancia);
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            catch (Exception ex)
            {
                GestorEventos.LogError(LogManager.GetCurrentClassLogger(), "APLICATIVO WFCOMERCIAL - DeleteConfirmed POST ", ex);
                return null;
                throw;
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
