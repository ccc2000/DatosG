﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using WFComercialWebApp.Models;
using Bitacora;
using NLog;
using WFComercialWebApp.DT_Datos;

namespace WFComercialWebApp.Controllers
{
    public class GraficosController : Controller
    {
        // GET: Graficos
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult Graficos()
        {
            return View();
        }




        [HttpGet]
        public JsonResult Grafico1()
        {
            DT_Reporte objDT_Reporte = new DT_Reporte();

            List<Grafico1> objLista = objDT_Reporte.RetornarGrafico1();

            return Json(objLista, JsonRequestBehavior.AllowGet);
        }



        [HttpGet]
        public JsonResult Loperaciones()
        {
            DT_Reporte objDT_Reporte = new DT_Reporte();

            List<ListaOperaciones1> objLista = objDT_Reporte.ListarOperacion();

            return Json(objLista, JsonRequestBehavior.AllowGet);
        }


    }
}